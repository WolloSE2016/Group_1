/*Write a function that accepts an array of non-negative integers and returns the second
largest integer in the array. Return -1 if there is no second largest.
The signature of the function is
int f(int[ ] a) */
package com.mycompany.paired;
import java.util.Scanner;

public class SeconLarge {

    public int f(int[] a) {
        if (a == null || a.length < 2)
            return -1;

        int largest = -1;
        int secondLargest = -1;

       for (int i = 0; i < a.length; i++) {
              int num = a[i];
          if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num < largest && num > secondLargest) {
                secondLargest = num;
            }
        }

        return secondLargest;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = scanner.nextInt();
      
        if (n <= 0) {
            System.out.println("Invalid array size.");
            return;
        }

        int[] a = new int[n];
       
       System.out.println("Enter " + n + " non-negative integers:");
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
  
      SeconLarge obj = new SeconLarge();
        int result = obj.f(a);

        if (result == -1) {
            System.out.println("There is no second largest number.");
        } else {
            System.out.println("The second largest number is: " + result);
        }
    }
}


