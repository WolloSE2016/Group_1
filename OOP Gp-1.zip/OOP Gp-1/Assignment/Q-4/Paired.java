/*
 An array is defined to be paired-Nif it contains two distinct elements that sum to N for
some specified value of N and the indexes of those elements also sum to N. Write a
function named isPairedN that returns 1 if its array parameter is a paired-N array . The
value of N is passed as the second parameter.
If you are writing in Java or C#, the function signature is
 int isPairedN(int[ ] a, int n)
If you are writing in C or C++, the function signature is
 int isPairedN(int a[ ], int n, int len) where len is the length of a
There are two additional requirements.
 . Once you know the array is paired-N, you should return 1. No wasted loop
iterations please.
 Do not enter the loop unless you have to. You should test the length of the array
and the value of n to determine whether the array could possibly be a paired-N
array. If the tests indicate no, return 0 before entering the loop.
 */
package paired;
public class paired {
    public static int isPairedN(int[] arr, int N) {
   
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
             if (arr[i] + arr[j] == N && i + j == N) {
                    return 1;  
                }
            }
        }
        return 0;  
    }

    public static void main(String[] args) {
        int[] pairedN = {0, 4, 2, 3, 4};
        int N1 = 4;
  
        //System.out.println(isPairedN(pairedN , N1));  
            if(isPairedN(pairedN , N1)==1){
            System.out.println("in the array there is paired-N");
            System.out.println(1);
            }
            else {
                System.out.println("in the array there is no  paired-N");
                System.out.println("-1");
                    }
          // to check for not paired we use the follwoing example  
        int[] example2 = {1, 2, 1, 2};
        int N2 = 3;
     
       isPairedN(example2 , N2);
    }
}

                                                                                                                                                                                                                                                                       