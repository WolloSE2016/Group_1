/*
Write a function named sameNumberOfFactorsthat takes two integer arguments and
returns 1 if they have the same number of factors. If either argument is negative, return -
1. Otherwise return 0.
int sameNumberOfFactors(int n1, int n2)
 
 */

package com.mycompany.factor;
import java.util.Scanner;

public class Factor {

   public static int sameNumbeoffactor(int a, int b){
        if (a<0 || b<0){
            return -1;
        }
        int fact1 = 0;
        int fact2 = 0;
        for (int i = 1; i <= a; i++){ 
            if (a % i == 0){
                fact1++;
            }
        }
        for (int i = 1; i <= b; i++){
            if (b % i == 0){
                fact2++;
            }
        }
        if (fact1 == fact2){
            return 1;
        } else {
            return 0;
        }
    }
    public static void main(String[] args) {
    System.out.println("Enter two integers:");
         Scanner scanner = new Scanner(System.in);
            int a =scanner .nextInt();
            int b = scanner.nextInt();

            int result = sameNumbeoffactor(a, b);

            if (result == -1) {
                System.out.println("Either argument is negative.");
                System.out.println("-1");
                    
            } else if (result == 1) {
                System.out.println("Both numbers have the same number of factors.");
                  System.out.println("1");
            } else {
                System.out.println("Both numbers do not have the same number of factors.");
                  System.out.println("0");
            }
        }
    
}


