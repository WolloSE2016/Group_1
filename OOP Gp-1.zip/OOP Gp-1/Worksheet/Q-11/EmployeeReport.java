public class EmployeeReport {
    public static void main(String[] args) {
        // Create and initialize the employee data array
        Employee[] employeeData = new Employee[100];
        
        // Add some sample employees (in a real program, this would be loaded from a file or database)
        employeeData[0] = new Employee("Smith", "John", 25.50, 15);
        employeeData[1] = new Employee("Johnson", "Sarah", 32.75, 22);
        employeeData[2] = new Employee("Williams", "Michael", 28.00, 20);
        employeeData[3] = new Employee("Brown", "Emily", 35.25, 5);
        employeeData[4] = new Employee("Jones", "David", 40.00, 25);
        // The remaining 95 elements would be null in this example
        
        // Print employees with 20+ years of service
        System.out.println("Employees with 20+ years of service:");
        System.out.println("------------------------------------");
        
        for (Employee employee : employeeData) {
            if (employee != null && employee.yearsWithCompany >= 20) {
                System.out.println("First Name: " + employee.firstName);
                System.out.println("Last Name: " + employee.lastName);
                System.out.println("Hourly Wage: $" + employee.hourlyWage);
                System.out.println("Years with Company: " + employee.yearsWithCompany);
                System.out.println(); // Empty line for separation
            }
        }
    }
}

class Employee {
    String lastName;
    String firstName;
    double hourlyWage;
    int yearsWithCompany;
    
    // Constructor
    public Employee(String lastName, String firstName, double hourlyWage, int yearsWithCompany) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.hourlyWage = hourlyWage;
        this.yearsWithCompany = yearsWithCompany;
    }
}
