/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.counter;

/**
 *
 * @author Hp
 */
public class Counter {
    private int value;

    public Counter() {
        value = 0;
    }

    public void increment() {
        value++;
    }
    public int getValue() {
        return value;
    }
    public static void main (String args[]) {
    Counter counter = new Counter ();
    counter.increment();
    counter.increment();
    counter.increment();
    counter.increment();
    System.out.print("Current Counter value is: "+counter.getValue());
    }
}



