/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.player;

/**
 *
 * @author Hp
 */
public class Player {
    private String name;
    private int score;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    // Main method to run the program
    public static void main(String[] args) {
        Player player = new Player();
        player.setName("John");
        player.setScore(100);

        System.out.println("Player Name: " + player.getName());
        System.out.println("Player Score: " + player.getScore());
    }
}


