/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.average;

/**
 *
 * @author Hp
 */
public class Average {

    public static void main(String[] args) {
        double[] A = {15, 40, 32, 4, 15, 55, 20, 21, 10, 63,
                       74, 53, 88, 30, 99, 20, 10, 13, 11, 12};
        double sum = 0.0;
        int count = 0;
        for (int i = 0; i < A.length; i++) {
            if (A[i] != 0) {
                sum += A[i]; 
                count++;     
            }
        }
        if (count > 0) {
            double average = sum / count; // Calculate average
            System.out.println("The average of non-zero numbers is: " + average);
        } else {
            System.out.println("There are no non-zero numbers in the array.");
        }
    }
}


    
    
