public class PrimeHappyChecker {
    
    /*
     * Checks if a number is prime-happy
     * @param n The number to check
     * @return 1 if prime-happy, 0 otherwise
     */
    public static int isPrimeHappy(int n) {
        // Edge cases: numbers less than 2 can't be prime-happy
        if (n <= 2) {
            return 0;
        }
        
        // Step 1: Find all primes less than n
        int sumOfPrimes = 0;
        boolean hasPrimes = false;
        
        for (int i = 2; i < n; i++) {
            if (isPrime(i)) {
                sumOfPrimes += i;
                hasPrimes = true;
            }
        }
        
        // Must have at least one prime and sum divisible by n
        return (hasPrimes && sumOfPrimes % n == 0) ? 1 : 0;
    }
    
    /*
     * Helper method to check if a number is prime
     * @param num Number to check
     * @return true if prime, false otherwise
     */
    private static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    // Test cases
    public static void main(String[] args) {
        System.out.println(isPrimeHappy(5));   // Output: 1 (2 + 3 = 5, 5/5=1)
        System.out.println(isPrimeHappy(25));  // Output: 1 (Sum=100, 100/25=4)
        System.out.println(isPrimeHappy(32));  // Output: 1 (Sum=160, 160/32=5)
        System.out.println(isPrimeHappy(2));   // Output: 0 (No primes < 2)
        System.out.println(isPrimeHappy(4));   // Output: 0 (2+3=5, 5%4≠0)
    }
}