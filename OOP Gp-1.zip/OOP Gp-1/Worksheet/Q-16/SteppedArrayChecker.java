public class SteppedArrayChecker {

    public static int isStepped(int[] a) {
        // Check if array is in ascending order
        for (int i = 0; i < a.length - 1; i++) {
            if (a[i] > a[i + 1]) {
                return 0; // Not ascending order
            }
        }
        
        // Count occurrences of each number
        int current = a[0];
        int count = 1;
        
        for (int i = 1; i < a.length; i++) {
            if (a[i] == current) {
                count++;
            } else {
                // Check if previous number had at least 3 occurrences
                if (count < 3) {
                    return 0;
                }
                current = a[i];
                count = 1;
            }
        }
        
        // Check the last number's count
        return count >= 3 ? 1 : 0;
    }

    // Test cases
    public static void main(String[] args) {
        System.out.println(isStepped(new int[]{1,1,1,5,5,5,5,8,8,8}));  // 1 (good)
        System.out.println(isStepped(new int[]{1,1,5,5,5,5,8,8,8}));     // 0 (only two 1's)
        System.out.println(isStepped(new int[]{5,5,5,15}));              // 0 (only one 15)
        System.out.println(isStepped(new int[]{3,3,3,2,2,2,5,5,5}));     // 0 (not ascending)
        System.out.println(isStepped(new int[]{3,3,3,2,2,2,1,1,1}));     // 0 (not ascending)
    }
}