/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;


public class Main {
    public static void main(String[] args) {
        // For loop to print multiples of 3 from 3 to 36
        for (int i = 3; i <= 36; i += 3) {
            System.out.print(i + " ");
        }
    }
}


