public class TestPairOfDice {
    public static void main(String[] args) {
        PairOfDice dice = new PairOfDice();
        int rollsUntilSnakeEyes = 0;
        
        do {
            dice.roll();
            rollsUntilSnakeEyes = dice.getRollCount();
        } while (dice.getTotal() != 2);
        
        System.out.println("It took " + rollsUntilSnakeEyes + " rolls to get snake eyes!");
        System.out.println("Final roll: " + dice);
    }
}