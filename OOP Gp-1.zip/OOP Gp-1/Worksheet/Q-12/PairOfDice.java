public class PairOfDice {
    // Private instance variables to protect the dice values
    private int die1;
    private int die2;
    private int rollCount;  // Tracks how many times the dice have been rolled
    
    // Constructor initializes the dice to 1 (standard dice start value)
    public PairOfDice() {
        die1 = 1;
        die2 = 1;
        rollCount = 0;
    }
    
    // Rolls both dice and returns their sum
    public int roll() {
        die1 = (int)(Math.random() * 6) + 1;
        die2 = (int)(Math.random() * 6) + 1;
        rollCount++;
        return die1 + die2;
    }
    
    // Getter methods to access dice values safely
    public int getDie1() {
        return die1;
    }
    
    public int getDie2() {
        return die2;
    }
    
    // Returns the sum of both dice
    public int getTotal() {
        return die1 + die2;
    }
    
    // Returns how many times the dice have been rolled
    public int getRollCount() {
        return rollCount;
    }
    
    // Resets the roll counter
    public void resetRollCount() {
        rollCount = 0;
    }
    
    // Returns a string representation of the dice
    @Override
    public String toString() {
        return "Die 1: " + die1 + ", Die 2: " + die2;
    }
}