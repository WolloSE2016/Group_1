/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;


public class Main {

    public static int findLargest(int[] numbers) {
        if (numbers == null || numbers.length == 0) {
            throw new IllegalArgumentException("Array must not be empty");
        }
        int largest = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > largest) {
                largest = numbers[i];
            }
        }
        return largest; 
    }
    public static void main(String[] args) {
        int[] array = {3, 5, 7, 2, 8, 1, 4};
        int largestValue = findLargest(array);
        System.out.println("The largest value in the array is: " + largestValue);
    }
}




