/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cointosssimulator;

/**
 *
 * @author Hp
 */
public class CoinTossSimulator {
    public static void main(String[] args) {
        Counter headCount = new Counter(); 
        Counter tailCount = new Counter(); 

        for (int i = 0; i < 100; i++) {
            int toss = (int) (Math.random() * 2); 
            if (toss == 1) {
                headCount.increment(); 
            } else {
                tailCount.increment(); 
            }
        }
        System.out.println("Heads: " + headCount.getValue());
        System.out.println("Tails: " + tailCount.getValue());
    }
}

