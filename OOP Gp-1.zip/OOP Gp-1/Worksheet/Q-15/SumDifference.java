public class SumDifference {
    public static int f(int[] a) {
        int sumOdd = 0; // Sum of odd numbers (X)
        int sumEven = 0; // Sum of even numbers (Y)
        
        for (int num : a) {
            if (num % 2 != 0) {
                sumOdd += num; // Add to odd sum if number is odd
            } else {
                sumEven += num; // Add to even sum if number is even
            }
        }
        
        return sumOdd - sumEven; // Return X - Y
    }

    public static void main(String[] args) {
        // Test cases
        System.out.println(f(new int[]{1}));           // Output: 1
        System.out.println(f(new int[]{1, 2}));        // Output: -1
        System.out.println(f(new int[]{1, 2, 3}));     // Output: 2
        System.out.println(f(new int[]{1, 2, 3, 4}));  // Output: -2
        System.out.println(f(new int[]{3, 3, 4, 4}));  // Output: -2
        System.out.println(f(new int[]{3, 2, 3, 4}));  // Output: 0
        System.out.println(f(new int[]{4, 1, 2, 3}));  // Output: -2
        System.out.println(f(new int[]{1, 1}));        // Output: 2
        System.out.println(f(new int[]{}));            // Output: 0
    }
}
