public class FibonacciFinder {
    public static int closestFibonacci(int n) {
        if (n < 1) {
            return 0;
        }
        
        if (n == 1) {
            return 1;
        }
        
        int a = 1; // Fibonacci(n-2)
        int b = 1; // Fibonacci(n-1)
        int c = a + b; // Fibonacci(n)
        
        while (c <= n) {
            a = b;
            b = c;
            c = a + b;
        }
        
        return b;
    }

    public static void main(String[] args) {
        // Test cases
        System.out.println(closestFibonacci(12));  // Should return 8
        System.out.println(closestFibonacci(33));  // Should return 21
        System.out.println(closestFibonacci(34));  // Should return 34
        System.out.println(closestFibonacci(1));   // Should return 1
        System.out.println(closestFibonacci(0));   // Should return 0
        System.out.println(closestFibonacci(-5));  // Should return 0
    }
}
