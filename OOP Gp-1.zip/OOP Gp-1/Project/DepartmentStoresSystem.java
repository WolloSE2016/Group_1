///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// */

package com.mycompany.departmentstoressystem;
//
///**
// *
// * @author Hp
// */
//public class DepartmentStoresSystem {
//
//    public static void main(String[] args) {
//        System.out.println("Hello World!");
//    }
//}
import java.util.*;

public class DepartmentStoresSystem {
    static Scanner scanner = new Scanner(System.in);

    static class Product {
        int id;
        String name;
        int stock;
        int borrowedCount;
        int returnedCount;

        Product(int id, String name, int stock) {
            this.id = id;
            this.name = name;
            this.stock = stock;
            this.borrowedCount = 0;
            this.returnedCount = 0;
        }
    }

    static List<Product> products = new ArrayList<>();
    static Map<Integer, Integer> borrowedProducts = new HashMap<>();
    static List<String> transactions = new ArrayList<>();
    static List<String> returnedProducts = new ArrayList<>();

    public static void main(String[] args) {
        showWelcome();
        mainMenu();
    }

    static void showWelcome() {
        System.out.println("=========================================");
        System.out.println("  Welcome to Department Store System");
        System.out.println("  " + new Date());
        System.out.println("=========================================");
    }

    static void mainMenu() {
        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. View Products");
            System.out.println("2. Add Products");
            System.out.println("3. Borrow Products");
            System.out.println("4. Return Products");
            System.out.println("5. View Borrowed Products");
            System.out.println("6. View Transaction Report");
            System.out.println("7. Inventory Report");
            System.out.println("8. View Popular Products");
            System.out.println("9. View Returned Products");
            System.out.println("10. Exit");

            int choice = getInt("Enter your choice: ");
            switch (choice) {
                case 1 -> viewProducts();
                case 2 -> addProduct();
                case 3 -> borrowProduct();
                case 4 -> returnProduct();
                case 5 -> viewBorrowed();
                case 6 -> viewTransactions();
                case 7 -> inventoryReport();
                case 8 -> viewPopular();
                case 9 -> viewReturned();
                case 10 -> {
                    System.out.println("Thank you for using the system. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice. Please enter 1-10.");
            }
        }
    }

    static void viewProducts() {
        System.out.println("\n--- View Products ---");
        if (products.isEmpty()) {
            System.out.println("No products available.");
        } else {
            for (Product p : products) {
                System.out.println("ID: " + p.id + " | Name: " + p.name + 
                                 " | Stock: " + p.stock + " | Borrowed: " + p.borrowedCount + 
                                 " | Returned: " + p.returnedCount);
            }
        }
        backToMenu();
    }

    static void addProduct() {
        System.out.println("\n--- Add Product ---");
        int id = getInt("Enter Product ID: ");
        
        if (getProductById(id) != null) {
            System.out.println("Product ID already exists. Please use a different ID.");
            backToMenu();
            return;
        }
        
        String name;
        while (true) {
            System.out.print("Enter Product Name: ");
            name = scanner.nextLine().trim();
            if (name.isEmpty()) {
                System.out.println("Product name cannot be empty.");
                continue;
            }
            if (!name.matches("[a-zA-Z ]+")) {
                System.out.println("Invalid name. Only letters and spaces are allowed.");
                continue;
            }
            break;
        }
        
        int stock = getInt("Enter Stock Quantity: ");
        products.add(new Product(id, name, stock));
        System.out.println("Product added successfully.");
        backToMenu();
    }

    static void borrowProduct() {
        System.out.println("\n--- Borrow Product ---");
        int id = getInt("Enter Product ID to borrow: ");
        Product product = getProductById(id);
        
        if (product == null) {
            System.out.println("Invalid product ID.");
            backToMenu();
            return;
        }

        int qty = getInt("Enter Quantity: ");
        if (qty <= 0) {
            System.out.println("Quantity must be positive.");
            backToMenu();
            return;
        }

        if (product.stock >= qty) {
            product.stock -= qty;
            product.borrowedCount += qty;
            borrowedProducts.put(id, borrowedProducts.getOrDefault(id, 0) + qty);
            transactions.add("Borrowed " + qty + " of " + product.name);
            System.out.println("Product borrowed successfully.");
        } else {
            System.out.println("Not enough stock.");
        }
        backToMenu();
    }

    static void returnProduct() {
        System.out.println("\n--- Return Product ---");
        int id = getInt("Enter Product ID to return: ");
        Product product = getProductById(id);
        
        if (product == null) {
            System.out.println("Invalid product ID.");
            backToMenu();
            return;
        }

        if (!borrowedProducts.containsKey(id)) {
            System.out.println("This product was not borrowed and cannot be returned.");
            backToMenu();
            return;
        }

        int qty = getInt("Enter Quantity: ");
        if (qty <= 0) {
            System.out.println("Quantity must be positive.");
            backToMenu();
            return;
        }

        int currentlyBorrowed = borrowedProducts.get(id);
        if (qty > currentlyBorrowed) {
            System.out.println("Cannot return more than borrowed quantity. Currently borrowed: " + currentlyBorrowed);
            backToMenu();
            return;
        }

        product.stock += qty;
        product.borrowedCount -= qty;
        product.returnedCount += qty;
        borrowedProducts.put(id, currentlyBorrowed - qty);
        if (borrowedProducts.get(id) == 0) {
            borrowedProducts.remove(id);
        }
        transactions.add("Returned " + qty + " of " + product.name);
        returnedProducts.add("ID: " + id + " | Name: " + product.name + " | Qty: " + qty);
        System.out.println("Product returned successfully.");
        backToMenu();
    }

    static void viewBorrowed() {
        System.out.println("\n--- View Borrowed Products ---");
        if (borrowedProducts.isEmpty()) {
            System.out.println("No borrowed products.");
        } else {
            for (Map.Entry<Integer, Integer> entry : borrowedProducts.entrySet()) {
                Product p = getProductById(entry.getKey());
                if (p != null) {
                    System.out.println("ID: " + p.id + " | Name: " + p.name + " | Qty: " + entry.getValue());
                }
            }
        }
        backToMenu();
    }

    static void viewReturned() {
        System.out.println("\n--- View Returned Products ---");
        if (returnedProducts.isEmpty()) {
            System.out.println("No returned products.");
        } else {
            for (String r : returnedProducts) {
                System.out.println(r);
            }
        }
        backToMenu();
    }

    static void viewTransactions() {
        System.out.println("\n--- Transaction Report ---");
        if (transactions.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (String t : transactions) {
                System.out.println(t);
            }
        }
        backToMenu();
    }

    static void inventoryReport() {
        System.out.println("\n--- Inventory Report ---");
        for (Product p : products) {
            System.out.println(p.name + " | Stock: " + p.stock + " | Borrowed: " + p.borrowedCount + " | Returned: " + p.returnedCount);
        }
        backToMenu();
    }

    static void viewPopular() {
        System.out.println("\n--- Popular Products ---");
        if (products.isEmpty()) {
            System.out.println("No products available.");
        } else {
            products.stream()
                    .sorted((a, b) -> Integer.compare(b.borrowedCount, a.borrowedCount))
                    .limit(5)
                    .forEach(p -> System.out.println(p.name + " | Borrowed: " + p.borrowedCount));
        }
        backToMenu();
    }

    static Product getProductById(int id) {
        for (Product p : products) {
            if (p.id == id) return p;
        }
        return null;
    }

    static int getInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Enter a number.");
            }
        }
    }

    static void backToMenu() {
        System.out.print("\nPress Enter to return to the main menu...");
        scanner.nextLine();
    }
}